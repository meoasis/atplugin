<?php
/**
 * Plugin Name: Twilio Integration - Gloss
 * Plugin URI: https://www.glosstech.io/
 * Description: Twilio Integration for AlphaTrends
 * Version: 1.3
 * Author: Romeo Asis jr
 * Author URI: https://www.glosstech.io/
 */
 //error_reporting(0);
use Twilio\Rest\Client;
require __DIR__ . '/twilio-php-master/Twilio/autoload.php';

require 'plugin-auto-updater/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'http://junieman.x10host.com/twilio_at_plugin_update.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'twilio-gloss'
);





 add_action('admin_menu', 'twilio_alphatrends_function');
 add_action( 'admin_init', 'twglo__settings_init' );
 add_action( 'admin_init', 'twglo__settings2_init' );
 add_action( 'admin_init', 'twglo__settings3_init' );
 add_action( 'admin_init', 'twglo__settings4_init' );
 add_action( 'admin_init', 'twglo__settings6_init' );

add_action( 'show_user_profile', 'twilio_integration_gloss_phone_number' );
add_action( 'edit_user_profile', 'twilio_integration_gloss_phone_number' );
add_action('save_post_premium_articles','premium_articles_hook_save');
//add_action( 'admin_post_update', 'bulk_sms_twilio_alphatrends' );

function premium_articles_hook_save($post_id){

    //$post = get_queried_object();

	//echo pmpro_page_meta();
$options = get_option( 'twglo__settings' );
$options_3 = get_option( 'twglo__settings3' );
$options_6 = get_option( 'twglo__settings6' );

$page_id= $post_id;
//$page_id="86793";
//$user_id="5705";

global $wpdb;
$pmpro_memberships_pages         = $wpdb->prefix . 'pmpro_memberships_pages';
$pmpro_memberships_users   = $wpdb->prefix . 'pmpro_memberships_users';
$sid_at= $options['twglo__text_field_0'];
$token_at= $options['twglo__text_field_1'];
$phone_at= $options['twglo__text_field_2'];
$body_at= $options_3['twglo__textarea_field_4'];

$endofday_tag= $options_6['twglo__text_field_88'];
$midday_tag= $options_6['twglo__text_field_89'];




//echo $sid_at.'<br>';
//echo $token_at.'<br>';
//echo $phone_at.'<br>';
//echo $body_at.'<br>';




 $checko_array = $wpdb->get_results("SELECT P.user_id, EV.page_id FROM wp_pmpro_memberships_pages as EV JOIN wp_pmpro_memberships_users as P ON EV.membership_id = P.membership_id WHERE EV.page_id = $page_id");

//echo '<pre>';
//print_r($checko_array);
//echo '</pre>';




foreach ($checko_array as $check_usr) {
	$phone_num= get_user_meta( $check_usr->user_id, 'tw_glo_phone_number' , true );
	$um_eodv= get_user_meta( $check_usr->user_id, 'endofdayvideos', true);
	$um_mdv= get_user_meta( $check_usr->user_id, 'middayvideos', true);
	//echo $phone_num;
if (! empty($phone_num)) {
        if ( is_tag($endofday_tag) && $um_eodv == 1 || is_tag($midday_tag) && $um_mdv == 1 ) {
					// Your Account SID and Auth Token from twilio.com/console
					$sid = $sid_at;
					$token = $token_at;
					$client = new Client($sid, $token);

					// Use the client to do fun stuff like send text messages!
					$client->messages->create(
						// the number you'd like to send the message to
						$phone_num,
						array(
							// A Twilio phone number you purchased at twilio.com/console
						   'from' => $phone_at,
							// the body of the text message you'd like to send
							'body' => $body_at
						)
					);
			}

}

}




}




function twlio_gloss_assets($hook) {
	if( (strpos($hook, 'twilio-gloss') !== false) ) {
	wp_register_script( 'sweetalert', 'https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js', array( 'jquery' ),'', true );
	wp_enqueue_script( 'sweetalert' );
  }
}

add_action( 'admin_enqueue_scripts', 'twlio_gloss_assets' );




function twilio_integration_gloss_phone_number( $user ) { ?>

	<table class="form-table">

		<tr>
			<th><label for="tw_glo_phone_number">Phone Number</label></th>

			<td>
				<input type="text" name="tw_glo_phone_number" id="tw_glo_phone_number" value="<?php echo esc_attr(get_the_author_meta( 'tw_glo_phone_number', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your phone number.</span>
			</td>
		</tr>

	</table>
<?php }




add_action( 'personal_options_update', 'twilio_integration_gloss_phone_number_update' );
add_action( 'edit_user_profile_update', 'twilio_integration_gloss_phone_number_update' );

function twilio_integration_gloss_phone_number_update( $user_id ) {

	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;

	update_usermeta( $user_id, 'tw_glo_phone_number', $_POST['tw_glo_phone_number'] );
}



function twglo__settings2_init(  ) {
	register_setting( 'twglo_pluginPage2', 'twglo__settings2' );

	add_settings_section(
 		'twglo__pluginPage2_section',
 		__( '', 'twiliogloass_textdomain' ),
 		'twglo__settings2_section_callback',
 		'twglo_pluginPage2'
 	);

	add_settings_field(
 		'twglo__select_field_3',
 		__( 'Membership Levels', 'twiliogloass_textdomain' ),
 		'twglo__select_field_3_render',
 		'twglo_pluginPage2',
 		'twglo__pluginPage2_section'
 	);


	add_settings_field(
 		'twglo__textarea_field_3',
 		__( 'SMS Message', 'twiliogloass_textdomain' ),
 		'twglo__textarea_field_3_render',
 		'twglo_pluginPage2',
 		'twglo__pluginPage2_section'
 	);


}


function twglo__settings3_init(  ) {
	register_setting( 'twglo_pluginPage3', 'twglo__settings3' );

	add_settings_section(
 		'twglo__pluginPage3_section',
 		__( '', 'twiliogloass_textdomain' ),
 		'twglo__settings3_section_callback',
 		'twglo_pluginPage3'
 	);

	add_settings_field(
 		'twglo__textarea_field_4',
 		__( 'SMS Message', 'twiliogloass_textdomain' ),
 		'twglo__textarea_field_4_render',
 		'twglo_pluginPage3',
 		'twglo__pluginPage3_section'
 	);


}



 function twglo__settings_init(  ) {

 	register_setting( 'twglo_pluginPage', 'twglo__settings' );

 	add_settings_section(
 		'twglo__pluginPage_section',
 		__( '', 'twiliogloass_textdomain' ),
 		'twglo__settings_section_callback',
 		'twglo_pluginPage'
 	);

 	add_settings_field(
 		'twglo__text_field_0',
 		__( 'Twilio Application SID', 'twiliogloass_textdomain' ),
 		'twglo__text_field_0_render',
 		'twglo_pluginPage',
 		'twglo__pluginPage_section'
 	);

  add_settings_field(
    'twglo__text_field_1',
    __( 'Auth Token', 'twiliogloass_textdomain' ),
    'twglo__text_field_1_render',
    'twglo_pluginPage',
    'twglo__pluginPage_section'
  );

  add_settings_field(
    'twglo__text_field_2',
    __( 'Twilio Phone Number', 'twiliogloass_textdomain' ),
    'twglo__text_field_2_render',
    'twglo_pluginPage',
    'twglo__pluginPage_section'
  );

 }


 function twglo__settings4_init(  ) {
 	register_setting( 'twglo_pluginPage4', 'twglo__settings4' );

 	add_settings_section(
  		'twglo__pluginPage4_section',
  		__( 'Add PMPro Membership Level ID on Basic/Premium Textbox separated with comma i.e. 12,23,9', 'twiliogloass_textdomain' ),
  		'twglo__settings4_section_callback',
  		'twglo_pluginPage4'
  	);


 	add_settings_field(
  		'twglo__textarea_field_43',
  		__( 'Basic PMPRO Level IDs', 'twiliogloass_textdomain' ),
  		'twglo__textarea_field_43_render',
  		'twglo_pluginPage4',
  		'twglo__pluginPage4_section'
  	);

		add_settings_field(
	  		'twglo__textarea_field_44',
	  		__( 'Premium PMPRO Level IDs', 'twiliogloass_textdomain' ),
	  		'twglo__textarea_field_44_render',
	  		'twglo_pluginPage4',
	  		'twglo__pluginPage4_section'
	  	);


 }


function twglo__settings6_init(  ) {

		register_setting( 'twglo_pluginPage6', 'twglo__settings6' );

		add_settings_section(
			'twglo__pluginPage6_section',
			__( '', 'twiliogloass_textdomain' ),
			'twglo__settings6_section_callback',
			'twglo_pluginPage6'
		);

	add_settings_field(
		'twglo__text_field_88',
		__( 'End OF Days Video ID', 'twiliogloass_textdomain' ),
		'twglo__text_field_88_render',
		'twglo_pluginPage6',
		'twglo__pluginPage6_section'
	);

	add_settings_field(
		'twglo__text_field_89',
		__( 'Mid Day Video Updates ID', 'twiliogloass_textdomain' ),
		'twglo__text_field_89_render',
		'twglo_pluginPage6',
		'twglo__pluginPage6_section'
	);

}










 function twglo__textarea_field_43_render(  ) {

 	$options = get_option( 'twglo__settings4' );
 	?><textarea id="texta" cols='40' rows='5' maxlength="150" name='twglo__settings4[twglo__textarea_field_43]'><?php echo $options['twglo__textarea_field_43']; ?></textarea><?php

 }

 function twglo__textarea_field_44_render(  ) {

 	$options = get_option( 'twglo__settings4' );
 	?><textarea id="texta" cols='40' rows='5' maxlength="150" name='twglo__settings4[twglo__textarea_field_44]'><?php echo $options['twglo__textarea_field_44']; ?></textarea><?php

 }


 function twglo__text_field_88_render(  ) {

 	$options = get_option( 'twglo__settings6' );
 	?>
 	<input type='text' name='twglo__settings6[twglo__text_field_88]' value='<?php echo $options['twglo__text_field_88']; ?>'>
 	<?php

 }

 function twglo__text_field_89_render(  ) {

 	$options = get_option( 'twglo__settings6' );
 	?>
 	<input type='text' name='twglo__settings6[twglo__text_field_89]' value='<?php echo $options['twglo__text_field_89']; ?>'>
 	<?php

 }





 function twglo__text_field_0_render(  ) {

 	$options = get_option( 'twglo__settings' );
 	?>
 	<input type='text' name='twglo__settings[twglo__text_field_0]' value='<?php echo $options['twglo__text_field_0']; ?>'>
 	<?php

 }

 function twglo__text_field_1_render(  ) {

   $options = get_option( 'twglo__settings' );
   ?>
   <input type='text' name='twglo__settings[twglo__text_field_1]' value='<?php echo $options['twglo__text_field_1']; ?>'>
   <?php

 }

 function twglo__text_field_2_render(  ) {

   $options = get_option( 'twglo__settings' );
   ?>
   <input type='text' name='twglo__settings[twglo__text_field_2]' value='<?php echo $options['twglo__text_field_2']; ?>'>
   <?php

 }

 function twglo__select_field_3_render(  ) {
	  $all_levels= pmpro_getAllLevels();
			$all_levels_array= array($all_levels);
			//echo '<pre>';
			//print_r($all_levels_array);
			//echo '</pre>';

 	$options_run = get_option( 'twglo__settings2' );
	 $check_level_1= esc_attr($options_run['twglo__select_field_3']);

 	?>
	  <select name='twglo__settings2[twglo__select_field_3]'>
	       <option value="">---Select Membership Level---</option>

	    <?php
			 foreach ($all_levels_array[0] as $pl_level) { ?>
			 <option value="<?php echo $pl_level->id; ?>" <?php selected( $check_level_1, $pl_level->id ); ?>><?php echo $pl_level->name; ?></option>
			 <?php }
		?>



	</select><?php

 }



 function twglo__textarea_field_3_render(  ) {

 	$options = get_option( 'twglo__settings2' );
 	?><div id="textarea_feedback"></div><textarea id="textarea" cols='40' rows='5' maxlength="150" name='twglo__settings2[twglo__textarea_field_3]'><?php echo $options['twglo__textarea_field_3']; ?></textarea><?php

 }

  function twglo__textarea_field_4_render(  ) {

 	$options = get_option( 'twglo__settings3' );
 	?><div id="textarea_feedback2"></div><textarea id="textarea2" cols='40' rows='5' maxlength="150" name='twglo__settings3[twglo__textarea_field_4]'><?php echo $options['twglo__textarea_field_4']; ?></textarea><?php

 }






 function twglo__settings_section_callback(  ) {

 	echo __( '', 'twiliogloass_textdomain' );

 }

 function twglo__settings2_section_callback(  ) {

 	echo __( '', 'twiliogloass_textdomain' );

 }

  function twglo__settings3_section_callback(  ) {

 	echo __( '', 'twiliogloass_textdomain' );

 }

 function twglo__settings4_section_callback(  ) {

	echo __( '', 'twiliogloass_textdomain' );

}

function twglo__settings6_section_callback(  ) {

 echo __( '', 'twiliogloass_textdomain' );

}







 function twilio_alphatrends_function()
 {
 	add_submenu_page( 'options-general.php', 'Twilio Integration', 'Twilio Integration', 'manage_options', 'twilio-gloss', 'twilio_alphatrends_function_main');
 }


 function twilio_alphatrends_function_main()
 { ?>



<div style="clear: both; display: block; padding: 30px 20px 20px;">
     <h1>Twilio Integration For AlphaTrends by GlossTech</h1>
     <p>*You can get your info below in twilio account or you may <a href="https://www.twilio.com/console" target="_blank">click here</a></p>





	  <style>

	        .wrapper {

			  width: 100%;
			  margin: -24px auto 0;
			}
			.tabs {
			  position: relative;
			  margin: 3rem 0;
			  background: #F1F1F1;
			  height: 14.75rem;
			}
			.tabs::before,
			.tabs::after {
			  content: "";
			  display: table;
			}
			.tabs::after {
			  clear: both;
			}
			.tab {
			  float: left;
			}
			.tab-switch {
			  display: none;
			}
			.tab-label {
			  position: relative;
			  display: block;
			  line-height: 2.75em;
			  height: 3em;
			  padding: 4px 87px;
			  background: #F1F1F1;
			  border: 1px solid #2E2E2E;
			  color: #2E2E2E;
			  cursor: pointer;
			  top: 0;
			  font-weight: 900;
			  margin-right: 10px;
			}
			.tab-label:hover {
			  /*top: -0.25rem;*/
			  /*transition: top 0.25s;*/
			}
			.tab-content {
			  height: 12rem;
			  position: absolute;
			  z-index: 1;
			  top: 55px;
			  left: 0;
			  padding: 1.618rem;
			  background: #F1F1F1;
			  color: #2c3e50;
			  /*border-bottom: 0.25rem solid #bdc3c7;*/
			  opacity: 0;
			  transition: all 0.35s;
			}
			.tab-switch:checked + .tab-label {
			  background: #2E2E2E;
			  color: #fff;
			  border-bottom: 0;
			  border: 1px solid #2E2E2E;
			  transition: all 0.35s;
			  z-index: 1;
			  font-weight: 900;
			}
			.tab-switch:checked + label + .tab-content {
			  z-index: 2;
			  opacity: 1;
			  transition: all 0.35s;
			}
			input[type="radio"].tab-switch{
				display: none !important;
			}
			.tw-gloss-plugin-content input[type=checkbox]{
				margin-bottom: 5px;
			}

			.tw-gloss-plugin-content  textarea{
				width: 100%;
			}

			.tw-gloss-plugin-content #textarea_feedback, .tw-gloss-plugin-content #textarea_feedback2{
				text-align: right;
				font-size: 11px;
				padding-right: 5px;
				padding-bottom: 5px;
			}
			.tw-gloss-plugin-content .tab1 tr:nth-child(2) td, .tw-gloss-plugin-content .tab1 tr:nth-child(3) td, .tw-gloss-plugin-content .tab1 tr:nth-child(4) td, .tw-gloss-plugin-content .tab1 tr:nth-child(5) td, .tw-gloss-plugin-content .tab1 tr:nth-child(6) td, .tw-gloss-plugin-content .tab1 tr:nth-child(7) td, .tw-gloss-plugin-content .tab1 tr:nth-child(8) td, .tw-gloss-plugin-content .tab1 tr:nth-child(9) td, .tw-gloss-plugin-content .tab1 tr:nth-child(10) td, .tw-gloss-plugin-content .tab1 tr:nth-child(11) td, .tw-gloss-plugin-content .tab1 tr:nth-child(12) td, .tw-gloss-plugin-content .tab1 tr:nth-child(13) td, .tw-gloss-plugin-content .tab1 tr:nth-child(14) td, .tw-gloss-plugin-content .tab1 tr:nth-child(15) td, .tw-gloss-plugin-content .tab1 tr:nth-child(16) td, .tw-gloss-plugin-content .tab1 tr:nth-child(17) td, .tw-gloss-plugin-content .tab1 tr:nth-child(18) td, .tw-gloss-plugin-content .tab1 tr:nth-child(19) td, .tw-gloss-plugin-content .tab1 tr:nth-child(20) td, .tw-gloss-plugin-content .tab1 tr:nth-child(21) td, .tw-gloss-plugin-content .tab1 tr:nth-child(22) td, .tw-gloss-plugin-content .tab1 tr:nth-child(23) td, .tw-gloss-plugin-content .tab1 tr:nth-child(24) td, .tw-gloss-plugin-content .tab1 tr:nth-child(25) td, .tw-gloss-plugin-content .tab1 tr:nth-child(26) td, .tw-gloss-plugin-content .tab1 tr:nth-child(27) td, .tw-gloss-plugin-content .tab1 tr:nth-child(28) td{
	padding:0 10px;
}
.sms_tw_form label{
    width: 220px;
  font-weight: 600;
}

.sms_tw_form{
  padding: 20px 7px;
}

#check {
    float: right;
    width: 379px;
}
#check label{
  position: relative;
  top: -5px;
}
#wpfooter{
	display: none !important;
}

.tab-content h1{
  font-size: 18px;
}

.tab-content h2{
	font-weight: normal;
	font-size: 14px;
	color: #555;
}
.irk span{
  display: inline-block !important;
  font-size: 12px;
}



	  </style>

     <div class="tw-gloss-plugin-content">
     <?php //echo bulk_sms_twilio_alphatrends(); ?>

		<div class="wrapper">
			  <div class="tabs">
				<div class="tab tab1">
				  <input type="radio" name="css-tabs" id="tab-1" checked class="tab-switch">
				  <label for="tab-1" class="tab-label">Bulk SMS</label>
				  <div class="tab-content">
				  <div class="alert_bar"></div>


				  <form action="" method="GET" class="sms_tw_form">
								<?php
								//settings_fields( 'twglo_pluginPage2' );
								//do_settings_sections( 'twglo_pluginPage2' );
								//submit_button('Send SMS','button-primary bulk-btn-send');

								//echo $_GET['membership'] .'<br>';
								//echo $_GET['bulk_sms_message'] .'<br>';

								global $wpdb;
		 $pmpro_users_table = $wpdb->prefix . "pmpro_memberships_users";
		 $pmpro_users_results = $wpdb->get_results("SELECT user_id, membership_id FROM $pmpro_users_table");

		 //echo '<pre>';
		 //print_r($pmpro_users_results);
		//echo '</pre>';

		$optionsir = get_option( 'twglo__settings' );
		 $options_bulksms_at = get_option( 'twglo__settings2' );
	     $membership_level=  $options_bulksms_at['twglo__select_field_3'];
		 $bulksms_message= $_GET['bulk_sms_message'];
		 //echo $membership_level.'<br>';
		 //echo $bulksms_message;

		 $sid_atir= $optionsir['twglo__text_field_0'];
         $token_atir= $optionsir['twglo__text_field_1'];
         $phone_atir= $optionsir['twglo__text_field_2'];

				$sicko= $_GET['membership'];
				//echo '<pre>';
				//print_r($sicko);
				//echo '</pre>';
        if(is_array($sicko)){
				foreach ($sicko as $key=>$value){
					    //echo $value .'<br>';
							foreach ($pmpro_users_results as $levu) {
							if ($value == $levu->membership_id ) {
								 $phonenum2= get_user_meta( $levu->user_id, 'tw_glo_phone_number' , true );
									 //echo $phonenum2;
									 // Your Account SID and Auth Token from twilio.com/console
										$sidi = $sid_atir;
										$tokeni = $token_atir;
										$clienti = new Client($sidi, $tokeni);

										// Use the client to do fun stuff like send text messages!
										$clienti->messages->create(
											// the number you'd like to send the message to
											'+'.$phonenum2,
											array(
												// A Twilio phone number you purchased at twilio.com/console
											   'from' => '+'.$phone_atir,
												// the body of the text message you'd like to send
												'body' => $bulksms_message
											)
										);

							}
							}
				}
			}






								$all_levels= pmpro_getAllLevels();
			                    $all_levels_array= array($all_levels);


								?>
								<input type="hidden" name="page" value="twilio-gloss"/>

								<?php
								   if ( isset($_GET['membership'])){ ?>

										 <script>
										 swal.fire({
										  title: "SMS Sent!",
										  //text: "Click ok to refresh the page.",
										  type: "success"
										}).then(function(){
											location.replace('<?php bloginfo('url'); ?>/wp-admin/options-general.php?page=twilio-gloss');
										});

										 </script>
								   <?php }
								?>
								<label style="float: left">SMS Message</label>
								<div class="text-area-div" style="float: right">
								<div id="textarea_feedback"></div><textarea id="textarea" name="bulk_sms_message" style="width: 451px; height: 127px;"></textarea>
								</div>
								<div style="clear: both; height: 35px;"></div>

								<label style="float: left">Membership</label>
								<select name="membership" style="float: right; visibility: hidden;" class="mems">
									<?php
			                         foreach ($all_levels_array[0] as $pl_level) { ?>
			                        <option value="<?php echo $pl_level->id; ?>"><?php echo $pl_level->name; ?></option>
			                         <?php } ?>
								</select>
								<div id="check"></div>
								<div style="clear: both;"></div>
								<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary bulk-btn-send" value="Send SMS"></p>


	                 </form>

				  </div>
				</div>
				<div class="tab">
				  <input type="radio" name="css-tabs" id="tab-2" class="tab-switch">
				  <label for="tab-2" class="tab-label">Automated SMS</label>
				  <div class="tab-content">
					<form action='options.php' method='post'>
								<?php
								settings_fields( 'twglo_pluginPage3' );
								do_settings_sections( 'twglo_pluginPage3' );
								submit_button();
								?>
	                    </form>
				  </div>
				</div>
				<div class="tab">
				  <input type="radio" name="css-tabs" id="tab-3" class="tab-switch">
				  <label for="tab-3" class="tab-label">Settings</label>
				  <div class="tab-content">

            <h1>Twilio Settings</h1>
						<form action='options.php' method='post'>
								<?php
								settings_fields( 'twglo_pluginPage' );
								do_settings_sections( 'twglo_pluginPage' );
								submit_button();
								?>
	           </form>
						 <div style="clear: both; height: 20px;"></div>
						 <hr>
             <div style="clear: both; height: 20px;"></div>
             <h1>Basic/Premium Membership Level Settings</h1>
						 <form action='options.php' method='post'>
 								<?php
 								settings_fields( 'twglo_pluginPage4' );
 								do_settings_sections( 'twglo_pluginPage4' );
 								submit_button();
 								?>
 	           </form>
						 <div style="clear: both; height: 20px;"></div>
						 <hr>
             <div style="clear: both; height: 20px;"></div>
             <h1>End of Day Video/Mid Day Video Settings</h1>
						 <form action='options.php' method='post'>
 								<?php
 								settings_fields( 'twglo_pluginPage6' );
 								do_settings_sections( 'twglo_pluginPage6' );
 								submit_button();
 								?>
 	           </form>
						 <div style="clear: both; height: 40px;"></div>
				  </div>
				</div>
			  </div>

			</div>


    </div>
</div>


<script>
jQuery(document).ready(function() {

    var text_max = 150;
    jQuery('#textarea_feedback').html(text_max + ' characters remaining');

    jQuery('#textarea').keyup(function() {
        var text_length = jQuery('#textarea').val().length;
        var text_remaining = text_max - text_length;

        jQuery('#textarea_feedback').html(text_remaining + ' characters remaining');
    });


	var text_max2 = 150;
    jQuery('#textarea_feedback2').html(text_max2 + ' characters remaining');

    jQuery('#textarea2').keyup(function() {
        var text_length = jQuery('#textarea2').val().length;
        var text_remaining = text_max2 - text_length;

        jQuery('#textarea_feedback2').html(text_remaining + ' characters remaining');
    });



});

</script>

<script>
jQuery(document).ready(function() {

jQuery(".mems option").each(function(i, e) {
  (jQuery("<input type='checkbox' name='membership[]' />")
    .attr("value", jQuery(this).val())
    //.attr("checked", i == 0)
    .click(function() {
      jQuery(".mems").val(jQuery(this).val());
    }).add(jQuery("<label>"+ this.textContent +"</label><br>")))
    .appendTo("#check");
});

});
</script>

<script>
function onlyOne(checkbox) {
    var checkboxes = document.getElementsByName('membership')
    checkboxes.forEach((item) => {
        if (item !== checkbox) item.checked = false
    })
}
</script>



 <?php

 }




function user_notification_settings_func( $user ) { ?>
  </ul>
	<hr>
	<?php
	   $current_user= wp_get_current_user();
   	$options_prembas_setup = get_option( 'twglo__settings4' );
		$basic_level=  $options_prembas_setup['twglo__textarea_field_43'];
		$prem_level=  $options_prembas_setup['twglo__textarea_field_44'];
	   $chek= pmpro_getMembershipLevelForUser(  $user_id = $user,  $force = true );
		 $subs_id= $chek->subscription_id;

		 //echo '<br>';
		 $baslev= $basic_level;
		 $fltr_arr_bas = explode (",", $baslev);
		 $premlev= $prem_level;
		 $fltr_arr_prem = explode (",", $premlev);
		 $full_bar_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
     global $wpdb;
		 $current_user = wp_get_current_user();
		 $eodv= $_GET['endofdayvideos'];
		 $mdv= $_GET['middayvideos'];
		 $chalk= $current_user->membership_level->ID;

		 //print_r($fltr_arr_prem);
		 //echo $subs_id;
		 foreach ($fltr_arr_prem as $key=>$value) {
		       if ($chalk == $value ){ ?>
		            <style>
		                 .incheck {
		                     display: block !important;
		                 }
		            </style>
		       <?php }
		 }
		 ?>
		 
		 <?php
						 if (isset($eodv) == 1) {
						 $wpdb->replace($wpdb->prefix.'usermeta', array(
							 'umeta_id' => '',
								'user_id' => $current_user->ID,
								'meta_key' => 'endofdayvideos',
								'meta_value' =>  1,
											 ));
						    }
						  ?>
						  
						  <?php
						 if (isset($mdv) == 1) {
							$wpdb->replace($wpdb->prefix.'usermeta', array(
								'umeta_id' => '',
								 'user_id' => $current_user->ID,
								 'meta_key' => 'middayvideos',
								 'meta_value' =>  1,
												));
						 }
						  ?>
		 
		 <div id="sms_notify_setup">
						 <h3>SMS Notification Settings</h3>
						 <div class="sms_account_level_settings">
							 <p class="irk"><span>*Alert Me via SMS for Latest "End of Day Videos"</span> <span class="incheck" style="display: none;">and "Mid Day Video Updates"</span>.</p>
							 <div style="clear: both; height: 20px;"></div>
							 <form action="<?php echo $full_bar_link; ?>" method="GET">
								 <input name="endofdayvideos" type="checkbox" value="1" <?php $endofdayvideo= get_user_meta( $current_user->ID, 'endofdayvideos', true); if ($endofdayvideo == 1) { echo "checked"; } ?>/> End of Day Videos <br/>
								 <span class="incheck" style="display: none;">
								 <input name="middayvideos" type="checkbox" value="1" <?php $middayvideo= get_user_meta( $current_user->ID, 'middayvideos', true); if ($middayvideo == 1) { echo "checked"; } ?>/> Mid Day Video Updates <br/>
								 </span>
								 <div style="clear: both; height: 20px;"></div>
								 <input type="submit" value="Notify Me"/>
							 </form>

						 </div>
					 </div>
		 
		 <?php


		 

	 ?>

	<hr>

<?php };

// add the action
add_action( 'pmpro_account_bullets_bottom', 'user_notification_settings_func', 10, 1 );
